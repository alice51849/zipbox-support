# Meeting notes

- Preview works without extracting
- Extract a single file from the list
- Multi part sets need every part in one folder
