import Foundation

struct Entry {
    let path: String
    let size: Int
    var isDirectory: Bool { path.hasSuffix("/") }
}
