Sample archive for Zipbox.

Everything in here is placeholder content created for testing.
Open the archive in Zipbox, browse the list, preview a file, then
extract one item or all of them.
